/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package moviedatabase;

/**
 *
 * @author Abdurrahman Khairi
 */
public enum genreEnum {
    ACTION,
    ADVENTURE,
    ANIMATION,
    BIOGRAPHY,
    COMEDY,
    CRIME,
    DOCUMENTARY,
    DRAMA,
    FICTION,
    FANTASY,
    HORROR,
    MUSICAL,
    MYSTERY,
    NOIR,
    ROMANCE,
    SCIENCE_FICTION,
    SCIENCE,
    SPORTS,
    THRILLER,
    WAR

}
